package models;

import config.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Classe représentant la possession d’un véhicule par un propriétaire
 * ------------------------------------------------
 * Objectifs pédagogiques BTS SIO :
 * 1. Comprendre une relation many-to-many avec attributs.
 * 2. Manipuler une clé primaire composée (id_proprietaire, id_vehicule).
 * 3. Gérer des dates via java.sql.Date.
 * 4. Implémenter les opérations CRUD avec JDBC.
 * 5. Sécuriser les requêtes avec PreparedStatement.
 * 6. Appliquer une logique métier (existence avant action).
 */
public class Posseder {

    private int idProprietaire;
    private int idVehicule;
    private Date dateDebut;
    private Date dateFin;

    // ================== GETTERS / SETTERS ==================

    public int getIdProprietaire() { return idProprietaire; }
    public void setIdProprietaire(int idProprietaire) { this.idProprietaire = idProprietaire; }

    public int getIdVehicule() { return idVehicule; }
    public void setIdVehicule(int idVehicule) { this.idVehicule = idVehicule; }

    public Date getDateDebut() { return dateDebut; }
    public void setDateDebut(Date dateDebut) { this.dateDebut = dateDebut; }

    public Date getDateFin() { return dateFin; }
    public void setDateFin(Date dateFin) { this.dateFin = dateFin; }

    // ================== equals / hashCode ==================
    // Basés sur la clé primaire composée

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Posseder)) return false;
        Posseder p = (Posseder) o;
        return idProprietaire == p.idProprietaire &&
               idVehicule == p.idVehicule;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProprietaire, idVehicule);
    }

    // ================== DAO / CRUD ==================

    /** Récupérer toutes les possessions */
    public static List<Posseder> getAllPossessions() {
        List<Posseder> liste = new ArrayList<>();
        String sql = "SELECT * FROM POSSEDER";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Posseder p = new Posseder();
                p.setIdProprietaire(rs.getInt("id_proprietaire"));
                p.setIdVehicule(rs.getInt("id_vehicule"));
                p.setDateDebut(rs.getDate("date_debut_propriete"));
                p.setDateFin(rs.getDate("date_fin_propriete"));
                liste.add(p);
            }

        } catch (SQLException e) {
            System.err.println("Erreur getAllPossessions : " + e.getMessage());
        }

        return liste;
    }

    /** Vérifier si une possession existe */
    public static boolean existsPossession(int idProprietaire, int idVehicule) {
        String sql = "SELECT COUNT(*) FROM POSSEDER WHERE id_proprietaire = ? AND id_vehicule = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idProprietaire);
            ps.setInt(2, idVehicule);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            System.err.println("Erreur existsPossession : " + e.getMessage());
        }

        return false;
    }

    /** Ajouter une possession */
    public static boolean addPossession(int idProprietaire, int idVehicule,
                                        Date dateDebut, Date dateFin) {

        if (existsPossession(idProprietaire, idVehicule)) return false;

        String sql = "INSERT INTO POSSEDER (id_proprietaire, id_vehicule, date_debut_propriete, date_fin_propriete) " +
                     "VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idProprietaire);
            ps.setInt(2, idVehicule);
            ps.setDate(3, dateDebut);
            ps.setDate(4, dateFin);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Erreur addPossession : " + e.getMessage());
        }

        return false;
    }

    /** Modifier une possession */
    public static boolean updatePossession(int idProprietaire, int idVehicule,
                                           Date dateDebut, Date dateFin) {

        if (!existsPossession(idProprietaire, idVehicule)) return false;

        String sql = "UPDATE POSSEDER SET date_debut_propriete = ?, date_fin_propriete = ? " +
                     "WHERE id_proprietaire = ? AND id_vehicule = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, dateDebut);
            ps.setDate(2, dateFin);
            ps.setInt(3, idProprietaire);
            ps.setInt(4, idVehicule);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Erreur updatePossession : " + e.getMessage());
        }

        return false;
    }

    /** Supprimer une possession */
    public static boolean deletePossession(int idProprietaire, int idVehicule) {

        if (!existsPossession(idProprietaire, idVehicule)) return false;

        String sql = "DELETE FROM POSSEDER WHERE id_proprietaire = ? AND id_vehicule = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idProprietaire);
            ps.setInt(2, idVehicule);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Erreur deletePossession : " + e.getMessage());
        }

        return false;
    }
}
